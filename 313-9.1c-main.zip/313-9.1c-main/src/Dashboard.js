// import React from "react";
// import { Button } from "react-bootstrap";
// import { useNavigate } from "react-router-dom";
// import { useUserAuth } from "./UserAuthContext";

// function Dashboard() {
//   const navigate = useNavigate();
//   const { signOut } = useUserAuth(); // Assuming you have a signOut function in your context

  

//   return (
//     <div>
//       <h1>Dashboard</h1>
//       <p>Welcome to the dashboard!</p>

//       {/* Add a sign-out button */}
//       <Button onClick={handleSignOut}>Sign Out</Button>
//     </div>
//   );
// }

// export default Dashboard;
